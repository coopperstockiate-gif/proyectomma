import { redirect } from 'next/navigation'

export default function Page() {
  redirect('/nexo-mma.html#gimnasio')
}
